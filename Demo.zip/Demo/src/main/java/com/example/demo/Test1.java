package com.example.demo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class Test1 {
public static void main(String[] args) {
	CopyOnWriteArrayList arrayList = new CopyOnWriteArrayList();
	arrayList.add("Rahul");
	arrayList.add("Ashish");
	arrayList.add("Hriyansh");
	System.out.println(arrayList);
	Iterator iterator = arrayList.iterator();
	while(iterator.hasNext())
	{
		String string = (String) iterator.next();
		System.out.println(string);
		arrayList.add("Bhavesh");
	}
}
}

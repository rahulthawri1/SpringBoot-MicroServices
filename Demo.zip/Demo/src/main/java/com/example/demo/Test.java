package com.example.demo;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;

import ch.qos.logback.core.db.dialect.MySQLDialect;

public class Test {


public static void main(String[] args) {
	TreeSet treeSet = new TreeSet(new MyComparator());
	treeSet.add(10);
	treeSet.add(20);
	treeSet.add(30);
	System.out.println(treeSet);
	
	
}
}
class MyComparator implements Comparator
{

	@Override
	public int compare(Object o1, Object o2) {
		Integer integer1 = (Integer) o1;
		Integer integer2 = (Integer) o2;
		return integer1.compareTo(integer2);
		//return integer2.compareTo(integer1);
	}
}



package com.resrful.services.specific.resources;

import org.hibernate.validator.constraints.Currency;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.resrful.services.specific.beans.User;

/**
 * @author rahuldigambart
 *
 */
@RestController
public class UserResource {
	@GetMapping(path = "/user")
	public String user() {
		return "Rahul";
	}

	// URI ==>> http://localhost:8080/user1
	@GetMapping(path = "/user1")
	public String user1() {
		return "Ashish";
	}
}

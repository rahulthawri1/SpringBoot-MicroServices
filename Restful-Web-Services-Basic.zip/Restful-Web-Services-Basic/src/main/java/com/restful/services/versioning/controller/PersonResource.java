package com.restful.services.versioning.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.restful.services.versioning.beans.Name;
import com.restful.services.versioning.beans.PersonV1;
import com.restful.services.versioning.beans.PersonV2;

/**
 * @author rahuldigambart
 *
 */
@RestController
public class PersonResource {
	// URI ==>> http://localhost:8080/v1/persion
	@GetMapping(path = "v1/person", produces = "application/xml")
	public PersonV1 persionV1() {
		return new PersonV1("Rahul");
	}

	// URI ==>> http://localhost:8080/v1/persion
	@GetMapping(path = "v2/person", produces = "application/json")
	public PersonV2 personV2() {
		return new PersonV2(new Name("Rahul", "Thawri"));
	}

	@GetMapping(value = "/person/param", params = "version=1")
	public PersonV1 paramV1() {
		return new PersonV1("Rahul");
	}
}

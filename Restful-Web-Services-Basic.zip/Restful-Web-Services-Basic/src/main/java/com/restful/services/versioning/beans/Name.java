package com.restful.services.versioning.beans;

/**
 * @author rahuldigambart
 *
 */
public class Name {
	private String firstName;
	private String lastname;

	/**
	 * 
	 */
	public Name() {
	}

	/**
	 * @param firstName
	 * @param lastname
	 */
	public Name(String firstName, String lastname) {
		this.firstName = firstName;
		this.lastname = lastname;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastname
	 */
	public String getLastname() {
		return lastname;
	}

	/**
	 * @param lastname the lastname to set
	 */
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	@Override
	public String toString() {
		return "Name [firstName=" + firstName + ", lastname=" + lastname + ", getFirstName()=" + getFirstName()
				+ ", getLastname()=" + getLastname() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}

}

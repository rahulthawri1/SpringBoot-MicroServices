package com.restful.services.article.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


import com.restful.services.article.beans.ArticleInfo;
import com.restful.services.article.service.ArticleDaoService;

/**
 * @author rahuldigambart
 *
 */
@RestController
public class ArticleController {
	@Autowired
	private ArticleDaoService articleDaoService;

	@GetMapping("/articles")
	public List<ArticleInfo> retriveAllArticle() {
		return articleDaoService.findAll();
	}

}

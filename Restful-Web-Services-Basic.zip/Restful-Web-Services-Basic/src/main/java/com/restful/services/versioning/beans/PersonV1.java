package com.restful.services.versioning.beans;

/**
 * @author rahuldigambart
 *
 */
public class PersonV1 {
	private String name;

	/**
	 * 
	 */
	public PersonV1() {
	}

	/**
	 * @param name
	 */
	public PersonV1(String name) {
		this.name = name;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", getName()=" + getName() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}

}

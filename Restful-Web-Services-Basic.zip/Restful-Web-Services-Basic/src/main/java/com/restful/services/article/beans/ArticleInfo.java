package com.restful.services.article.beans;

import java.io.Serializable;

/**
 * @author rahuldigambart
 *
 */
public class ArticleInfo implements Serializable {
	final static long serialVersionUID = 1L;
	private long articleId;
	private String name;
	private String category;

	/**
	 * 
	 */
	public ArticleInfo() {
	}

	/**
	 * @param articleId
	 * @param name
	 * @param category
	 */
	public ArticleInfo(long articleId, String name, String category) {
		this.articleId = articleId;
		this.name = name;
		this.category = category;
	}

	/**
	 * @return the articleId
	 */
	public long getArticleId() {
		return articleId;
	}

	/**
	 * @param articleId the articleId to set
	 */
	public void setArticleId(long articleId) {
		this.articleId = articleId;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "ArticleInfo [articleId=" + articleId + ", name=" + name + ", category=" + category + ", getArticleId()="
				+ getArticleId() + ", getName()=" + getName() + ", getCategory()=" + getCategory() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}

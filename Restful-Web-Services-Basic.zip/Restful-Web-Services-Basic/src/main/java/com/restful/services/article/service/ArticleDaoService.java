package com.restful.services.article.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.restful.services.article.beans.ArticleInfo;

/**
 * @author rahuldigambart
 *
 */
@Component
public class ArticleDaoService {
	private static List<ArticleInfo> articleInfos = new ArrayList<>();
	static {
		articleInfos.add(new ArticleInfo(1, "Java Concurrency", "Java"));
		articleInfos.add(new ArticleInfo(2, "Spring Boot Getting Started", "Spring Boot"));
		articleInfos.add(new ArticleInfo(3, "Lambda Expression Java 8 Example", "Java 8"));
	}

	public List<ArticleInfo> findAll() {
		return articleInfos;
	}
}

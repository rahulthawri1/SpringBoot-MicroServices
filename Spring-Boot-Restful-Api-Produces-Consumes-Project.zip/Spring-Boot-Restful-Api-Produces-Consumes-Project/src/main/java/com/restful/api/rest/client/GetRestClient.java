package com.restful.api.rest.client;

import org.springframework.web.client.RestTemplate;

/**
 * @author rahuldigambart
 *
 */
public class GetRestClient {
	static final String URL_USERS = "http://localhost:8080/users";

	public static void main(String[] args) {
		RestTemplate restTemplate = null;
		restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(URL_USERS, String.class);
		System.out.println(result);
	}
}

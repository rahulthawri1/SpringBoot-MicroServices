package com.restful.services;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfulWebServicesSwaggerDocumentationApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfulWebServicesSwaggerDocumentationApplication.class, args);
	}

}

package com.example.demo;

/**
 * @author rahuldigambart
 *
 */
public class Card {
	private long cardNumber;
	private String cardHolderName;
	private int cvv;
	private String cardType;

	/**
	 * 
	 */
	public Card() {
	}

	/**
	 * @param cardNumber
	 * @param cardHolderName
	 * @param cvv
	 * @param cardType
	 */
	public Card(long cardNumber, String cardHolderName, int cvv, String cardType) {
		this.cardNumber = cardNumber;
		this.cardHolderName = cardHolderName;
		this.cvv = cvv;
		this.cardType = cardType;
	}

	/**
	 * @return the cardNumber
	 */
	public long getCardNumber() {
		return cardNumber;
	}

	/**
	 * @param cardNumber the cardNumber to set
	 */
	public void setCardNumber(long cardNumber) {
		this.cardNumber = cardNumber;
	}

	/**
	 * @return the cardHolderName
	 */
	public String getCardHolderName() {
		return cardHolderName;
	}

	/**
	 * @param cardHolderName the cardHolderName to set
	 */
	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}

	/**
	 * @return the cvv
	 */
	public int getCvv() {
		return cvv;
	}

	/**
	 * @param cvv the cvv to set
	 */
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}

	/**
	 * @return the cardType
	 */
	public String getCardType() {
		return cardType;
	}

	/**
	 * @param cardType the cardType to set
	 */
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	@Override
	public String toString() {
		return "Card [cardNumber=" + cardNumber + ", cardHolderName=" + cardHolderName + ", cvv=" + cvv + ", cardType="
				+ cardType + ", getCardNumber()=" + getCardNumber() + ", getCardHolderName()=" + getCardHolderName()
				+ ", getCvv()=" + getCvv() + ", getCardType()=" + getCardType() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}

package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author rahuldigambart
 *
 */
@RestController
public class CardController {
	@GetMapping(path = "cards")
	public Card showDetails() {
		return new Card(48964, "Rahul Thawri", 786, "Credit Card");
	}
}

package com.example.demo;

/**
 * @author rahuldigambart
 *
 */
public class CreditCard {
	private int cardNumber;
	private String cardHolderName;
	private int cvv;

	/**
	 * 
	 */
	public CreditCard() {
	}

	/**
	 * @param cardNumber
	 * @param cardHolderName
	 * @param cvv
	 */
	public CreditCard(int cardNumber, String cardHolderName, int cvv) {
		this.cardNumber = cardNumber;
		this.cardHolderName = cardHolderName;
		this.cvv = cvv;
	}

	/**
	 * @return the cardNumber
	 */
	public int getCardNumber() {
		return cardNumber;
	}

	/**
	 * @param cardNumber the cardNumber to set
	 */
	public void setCardNumber(int cardNumber) {
		this.cardNumber = cardNumber;
	}

	/**
	 * @return the cardHolderName
	 */
	public String getCardHolderName() {
		return cardHolderName;
	}

	/**
	 * @param cardHolderName the cardHolderName to set
	 */
	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}

	/**
	 * @return the cvv
	 */
	public int getCvv() {
		return cvv;
	}

	/**
	 * @param cvv the cvv to set
	 */
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}

	@Override
	public String toString() {
		return "CreditCard [cardNumber=" + cardNumber + ", cardHolderName=" + cardHolderName + ", cvv=" + cvv
				+ ", getCardNumber()=" + getCardNumber() + ", getCardHolderName()=" + getCardHolderName()
				+ ", getCvv()=" + getCvv() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}

}

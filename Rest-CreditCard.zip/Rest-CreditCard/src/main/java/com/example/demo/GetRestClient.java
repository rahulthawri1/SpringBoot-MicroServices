package com.example.demo;

import org.springframework.web.client.RestTemplate;

/**
 * @author rahuldigambart
 *
 */
public class GetRestClient {

	static final String URL_CARDS = "http://localhost:8080/cards";
	

	public static void main(String[] args) {
		RestTemplate restTemplate = null;
		restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(URL_CARDS, String.class);
		System.out.println(result);
	}
}

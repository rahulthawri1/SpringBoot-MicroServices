package com.example.demo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

/**
 * @author rahuldigambart
 *
 */
@Component
public class CreditCardDaoService {
	// creating an instance of ArrayList
	private static List<CreditCard> cards = new ArrayList<>();
	static {
		// adding users to the list
		cards.add(new CreditCard(1234, "Rahul Thawri", 567));
		cards.add(new CreditCard(6789, "Ashish Thawri", 123));
	}

	// method that retrieve all cards from the list
	public List<CreditCard> findAll() {
		return cards;
	}

}

package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author rahuldigambart
 *
 */
@RestController
public class CreditCardController {
	@Autowired
	private CreditCardDaoService service;
// URI Link :- http://localhost:8080/cards
	@GetMapping("/cards")
	public List<CreditCard> retriveAllCards() {
		return service.findAll();
	}
	
	
	
}

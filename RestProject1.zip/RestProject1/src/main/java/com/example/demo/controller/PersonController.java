package com.example.demo.controller;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
//@Path("/api")
public class PersonController {

	@GetMapping(path = "/hello")

	// @GET
	// @Produces(MediaType.APPLICATION_JSON_VALUE)
	public String hello() {
		return "Hello World";
	}

	@GetMapping("/personV1")
	public PersonV1 helloPerson() {
		return new PersonV1("Rahul Thawri");
	}

	@GetMapping(path = "/personV2", produces = MediaType.APPLICATION_XML_VALUE)
	public PersonV2 helloPersonV2() {
		return new PersonV2(new Name("Rahul", "Thawri"));
	}

}

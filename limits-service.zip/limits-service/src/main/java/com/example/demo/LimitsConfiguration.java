package com.example.demo;

public class LimitsConfiguration {
private int min;
private int max;
/**
 * @param min
 * @param max
 */
public LimitsConfiguration(int min, int max) {
	this.min = min;
	this.max = max;
}
/**
 * @return the min
 */
public int getMin() {
	return min;
}
/**
 * @param min the min to set
 */
public void setMin(int min) {
	this.min = min;
}
/**
 * @return the max
 */
public int getMax() {
	return max;
}
/**
 * @param max the max to set
 */
public void setMax(int max) {
	this.max = max;
}
@Override
public String toString() {
	return "LimitsConfiguration [min=" + min + ", max=" + max + "]";
}
}

package com.example.demo;

import java.math.BigDecimal;

public class ExchangeValue {
private Long id;
private String from;
private String to;
private BigDecimal conversionMultiple;
private int port;
/**
 * @param port
 */
public ExchangeValue(int port) {
	this.port = port;
}
/**
 * 
 */
public ExchangeValue() {
}
/**
 * @param id
 * @param from
 * @param to
 * @param conversionMultiple
 */
public ExchangeValue(Long id, String from, String to, BigDecimal conversionMultiple) {
	this.id = id;
	this.from = from;
	this.to = to;
	this.conversionMultiple = conversionMultiple;
}
/**
 * @return the id
 */
public Long getId() {
	return id;
}
/**
 * @param id the id to set
 */
public void setId(Long id) {
	this.id = id;
}
/**
 * @return the from
 */
public String getFrom() {
	return from;
}
/**
 * @param from the from to set
 */
public void setFrom(String from) {
	this.from = from;
}
/**
 * @return the to
 */
public String getTo() {
	return to;
}
/**
 * @param to the to to set
 */
public void setTo(String to) {
	this.to = to;
}
/**
 * @return the conversionMultiple
 */
public BigDecimal getConversionMultiple() {
	return conversionMultiple;
}
/**
 * @param conversionMultiple the conversionMultiple to set
 */
public void setConversionMultiple(BigDecimal conversionMultiple) {
	this.conversionMultiple = conversionMultiple;
}
@Override
public String toString() {
	return "ExchangeValue [id=" + id + ", from=" + from + ", to=" + to + ", conversionMultiple=" + conversionMultiple
			+ ", getId()=" + getId() + ", getFrom()=" + getFrom() + ", getTo()=" + getTo()
			+ ", getConversionMultiple()=" + getConversionMultiple() + ", getClass()=" + getClass() + ", hashCode()="
			+ hashCode() + ", toString()=" + super.toString() + "]";
}
/**
 * @return the port
 */
public int getPort() {
	return port;
}
/**
 * @param port the port to set
 */
public void setPort(int port) {
	this.port = port;
}
}
